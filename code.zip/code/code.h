/*
Created by: Yeung Wing
Description: My code collection.
*/

#ifndef CODE_H
#define CODE_H

#include <Arduino.h>

class CODE
{
  public:
    //Easier to recognise where the code starts and ends on the Serial Monitor.
    void start(int sBegin = 115200);
    void end(int time = 4000);
};

#endif