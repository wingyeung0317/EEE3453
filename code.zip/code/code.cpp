/*
Created by: Yeung Wing
Description: My code collection.
*/

#include "code.h"

// Easier to recognise where the code starts on the Serial Monitor.
void CODE::start(int sBegin){
    Serial.begin(sBegin);
    Serial.println("[---Start---]");
}

// Determine how the program ends and easier to recognise where does the code end on the Serial Monitor.
void CODE::end(int time){
    // Repeat Program after `time and scrolling timer
    if (time>=0){
        Serial.println("\n[---END---]");
        delay(time/4);
        Serial.println("........");
        delay(time/4);
        Serial.println("....");
        delay(time/4);
        Serial.println(".");
        delay(time/4);
        Serial.println("[---Start---]");
    }
    // End Program by entering endless empty loop
    else{
        Serial.println("\n[---END---]");
        while(1);
    }
}